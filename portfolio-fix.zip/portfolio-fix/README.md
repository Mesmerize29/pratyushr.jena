# Immersive Portfolio Fix Pack

Replace your current `index.html`, `css/`, `js/`, and `data/` files with these versions.

## Why this version is safer
- Shows fallback content even if JS fails
- Wraps initialization in `DOMContentLoaded`
- Avoids depending on older monolithic files
- Uses only relative imports compatible with GitHub Pages
- Removes `color-mix()` dependency from the glow layer for broader compatibility

## Run locally
```bash
python3 -m http.server 8080
```
Then open `http://localhost:8080`
